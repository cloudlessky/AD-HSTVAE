# preprocess data
import numpy as np
import re


def get_most_common_features(target, all_features, max = 3, min = 3):
    res = []
    main_keys = target.split('_')

    for feature in all_features:
        if target == feature:
            #res.append(feature)
            continue

        f_keys = feature.split('_')
        common_key_num = len(list(set(f_keys) & set(main_keys)))

        if common_key_num >= min and common_key_num <= max:
            res.append(feature)

    return res

def build_net(target, all_features):

    # get edge_indexes, and index_feature_map
    main_keys = target.split('_')
    edge_indexes = [
        [],
        []
    ]
    index_feature_map = [target]

    # find closest features(nodes):
    parent_list = [target]
    graph_map = {}
    depth = 2
    
    for i in range(depth):        
        for feature in parent_list:
            children = get_most_common_features(feature, all_features)

            if feature not in graph_map:
                graph_map[feature] = []
            
            # exclude parent
            pure_children = []
            for child in children:
                if child not in graph_map:
                    pure_children.append(child)

            graph_map[feature] = pure_children

            if feature not in index_feature_map:
                index_feature_map.append(feature)
            p_index = index_feature_map.index(feature)
            for child in pure_children:
                if child not in index_feature_map:
                    index_feature_map.append(child)
                c_index = index_feature_map.index(child)

                edge_indexes[1].append(p_index)
                edge_indexes[0].append(c_index)

        parent_list = pure_children

    return edge_indexes, index_feature_map

#train_dataset_indata = construct_data(train, feature_map, labels=0)
def construct_data(data, labels=0):
    res = []

    # for feature in feature_map:
    #     if feature in data.columns:
    #         res.append(data.loc[:, feature].values.tolist())#把每一列数据添加到列表中（横向）
    #     else:
    #         print(feature, 'not exist in data')
    #for feature in feature_map:
    if 'attack' in data.columns:
        data = data.drop(columns=['attack'])#drop the "attack" column of test.csv
    for feature in data.columns:
        res.append(data.loc[:, feature].values.tolist())#把每一列数据添加到列表中（横向）
    # else:
    #     print(feature, 'not exist in data')
    # append labels as last
    sample_n = len(res[0])#res的第0维是行，获得行数，即样本个数，也即时间戳数

    if type(labels) == int:
        res.append([labels]*sample_n)
    elif len(labels) == sample_n:
        res.append(labels)

    return res

def construct_data_SMD(data, labels=0):
    res = []
    #print('data.shape[1]',data.shape[1])
    for feature in range(data.shape[1]):
        res.append(data[:,feature].tolist())#把每一列数据添加到列表中（横向）

    sample_n = len(res[0])#res的第0维是行，获得行数，即样本个数，也即时间戳数
    # print('*******sample_n', sample_n)
    # print('type(labels)',type(labels))

    if type(labels) == int:
        #print('00000000000000000000000000')
        res.append([labels]*sample_n)
    elif len(labels) == sample_n:
        #print('*******len(labels)', len(labels))
        res.append(labels)

    return res
#构建邻接矩阵
#fc_edge_index = build_loc_net(fc_struc, list(train.columns), feature_map=feature_map)
def build_loc_net(struc, all_features, feature_map=[]):

    #print('struc',struc)
    # print('all_features', len(all_features), all_features)
    # print('len(feature_map)', len(feature_map), feature_map)
    index_feature_map = feature_map
    edge_indexes = [#邻接矩阵
        [],
        []
    ]
    for node_name, node_list in struc.items():
        #print('len(node_list)',len(node_list))
        if node_name not in all_features:
            continue

        if node_name not in index_feature_map:
            index_feature_map.append(node_name)
        
        p_index = index_feature_map.index(node_name)#返回map中某个key的索引
        for child in node_list:
            if child not in all_features:
                continue

            if child not in index_feature_map:
                print(f'error: {child} not in index_feature_map')
                # index_feature_map.append(child)

            c_index = index_feature_map.index(child)#邻接孩子的索引
            # edge_indexes[0].append(p_index)
            # edge_indexes[1].append(c_index)
            edge_indexes[0].append(c_index)#二维tensor，第一维存孩子索引，第二维存key索引，构成邻接矩阵
            edge_indexes[1].append(p_index)
        

    
    return edge_indexes#返回邻接矩阵