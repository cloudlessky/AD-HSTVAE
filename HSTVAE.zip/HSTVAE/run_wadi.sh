gpu_n=$1
DATASET='wadi'
EPOCH=100

batch=200
group_index=0
index=0
slide_win=40
slide_stride=1
pred_win=5
ano_file_path='/home/xsq/VAEAGG/data/wadi/wadi_time.csv'
loss_path='loss_wadi'
num_tasks=98
LATENT_CODE_SIZE=3
kl_coff=30
rec_coff=1
rec_now_coff=1
pred_now_coff=1
pred_future_coff=1
dec_in=1
dim=64
down=10
topk=2
lr=0.001
patience=5
alpha=0.74
beta=0.08
device='cuda'
val_ratio=0.3
# load_model_path=('./pretrained/wadi/best_wadi-epoch30.pt')
for((i=0;i<=0;i++))
do
    CUDA_VISIBLE_DEVICES=$gpu_n python main.py \
        -dataset ${DATASET} \
        -epoch ${EPOCH} \
        -batch ${batch} \
        -group_index ${group_index} \
        -index ${index} \
        -slide_win ${slide_win} \
        -slide_stride ${slide_stride} \
        -pred_win ${pred_win} \
        -num_tasks ${num_tasks} \
        -LATENT_CODE_SIZE ${LATENT_CODE_SIZE} \
        -kl_coff ${kl_coff} \
        -pred_now_coff ${pred_now_coff} \
        -pred_future_coff ${pred_future_coff} \
        -rec_now_coff ${rec_now_coff} \
        -rec_coff ${rec_coff} \
        -dec_in ${dec_in} \
        -dim ${dim} \
        -down ${down} \
        -topk ${topk} \
        -lr ${lr} \
        -patience ${patience} \
        -ano_file_path ${ano_file_path} \
        -loss_path ${loss_path} \
        -alpha ${alpha} \
        -beta ${beta} \
        -device ${device} \
        -val_ratio ${val_ratio} \
        # -load_model_path ${load_model_path[i]} 
done
