gpu_n=$1
DATASET='SMD'
EPOCH=100

batch=512
group_index=(1 2 3)
index=(1 2 3 4 5 6 7 8 9 10 11)
slide_win=15
slide_stride=1
pred_win=5
ano_file_path='/home/xsq/VAEAGG/data/wadi/wadi_time.csv'
loss_path='loss_SMD'
num_tasks=38
LATENT_CODE_SIZE=3
kl_coff=50
rec_coff=1
rec_now_coff=1
pred_now_coff=1
pred_future_coff=1
dec_in=1
dim=64
down=1
topk=38
lr=0.001
patience=5
alpha=0.05
beta=0.05
device='cuda'
val_ratio=0.2
# load_model_path=('./pretrained/SMD/best_SMD_group1_index1.pt' './pretrained/SMD/best_SMD_group1_index2.pt' 
# './pretrained/SMD/best_SMD_group1_index3.pt' './pretrained/SMD/best_SMD_group1_index4.pt'
#  './pretrained/SMD/best_SMD_group1_index5.pt' './pretrained/SMD/best_SMD_group1_index6.pt'
#   './pretrained/SMD/best_SMD_group1_index7.pt' './pretrained/SMD/best_SMD_group1_index8.pt')


for((i=0;i<=0;i++))
do
 for((j=0;j<=0;j++))
 do
   CUDA_VISIBLE_DEVICES=$gpu_n python main.py \
    -dataset ${DATASET} \
    -epoch ${EPOCH} \
    -batch ${batch} \
    -group_index ${group_index[i]} \
    -index ${index[j]} \
    -slide_win ${slide_win} \
    -slide_stride ${slide_stride} \
    -pred_win ${pred_win} \
    -num_tasks ${num_tasks} \
    -LATENT_CODE_SIZE ${LATENT_CODE_SIZE} \
    -kl_coff ${kl_coff} \
    -pred_now_coff ${pred_now_coff} \
    -pred_future_coff ${pred_future_coff} \
    -rec_now_coff ${rec_now_coff} \
    -rec_coff ${rec_coff} \
    -dec_in ${dec_in} \
    -dim ${dim} \
    -down ${down} \
    -topk ${topk} \
    -lr ${lr} \
    -patience ${patience} \
    -ano_file_path ${ano_file_path} \
    -loss_path ${loss_path} \
    -alpha ${alpha} \
    -beta ${beta} \
    -device ${device} \
    -val_ratio ${val_ratio} \
    # -load_model_path ${load_model_path[j]} 
 done
done

