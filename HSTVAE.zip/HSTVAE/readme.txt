1、env
The hardware environment is described in the paper.
Configure the pytorch environment according to requirements.txt.

2、run
bash run_swat.sh 0 ("0" can be any cuda number)
And if you only want to test, you can set the "load_model_path" in .sh file.

3、dataset
The swat and wadi can be obtained from website marked in paper. And the data can be preprocessed as follow .
Firstly, normalize the data as described in the paper.
The swat drop the "p603".
The wadi drop those columns that are all 0 in both the training and testing sets after preprocessing.
The SMD and its preprocessing method is the same as paper "omni".


4、args
The parameter configurations for each dataset are shown in the corresponding .sh file. 
Specifically, for different datasets, the parameter "prior" needs to be set in the main.py file. 
In addition, for different datasets, the spatio_coff in lib/utils.py has different settings and has been annotated.